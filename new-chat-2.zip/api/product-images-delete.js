const {del}=require('@vercel/blob');
const {requireAdmin}=require('../lib/auth');
module.exports=async function(req,res){
  res.setHeader('Cache-Control','no-store');
  if(req.method!=='POST') return res.status(405).json({success:false,error:'Método não permitido.'});
  if(!requireAdmin(req,res)) return;
  try{
    if(!process.env.BLOB_READ_WRITE_TOKEN) return res.status(500).json({success:false,error:'BLOB_READ_WRITE_TOKEN não configurado.'});
    const urls=Array.isArray(req.body?.urls)?req.body.urls:[];
    const clean=[...new Set(urls.filter(Boolean).map(String))];
    // Only delete images that live in our own Blob store; ignore external URLs.
    const own=clean.filter(u=>/\.public\.blob\.vercel-storage\.com\//.test(u)||/\.blob\.vercel-storage\.com\//.test(u));
    if(own.length) await del(own);
    return res.status(200).json({success:true,deleted:own.length});
  }catch(e){console.error(e);return res.status(500).json({success:false,error:e.message||'Falha ao excluir imagens.'});}
};
